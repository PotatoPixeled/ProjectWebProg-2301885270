<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class Controller1 extends Controller
{
    public function store(Request $request)
    {
        $name = $request['name'];
        $age = $request['age'];
        $email = $request->input('email');
        $password = $request['password'];

        $user = new User();
        $user->name = $name;
        $user->age = $age;
        $user->email = $email;

        $user->password = $password;

        $user-> save();
            return redirect('/');

  }

}
