<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Order;
use Illuminate\Http\Request;

class menuController extends Controller
{
    function list(){
        $orders = Order::all();
        $menus = Menu::all();
        return view('menupage', ['orders'=>$orders, 'menus' => $menus]);
    }

    function delete($id){
        $items=Order::find($id);
        $items->delete();
        return redirect('menu');
    }
}
