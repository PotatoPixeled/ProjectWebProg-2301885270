<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Order;
use Illuminate\Http\Request;

class paymentController extends Controller
{


    public function show(){
        $orders = Order::all();
        $menus = Menu::all();

        return view('payment', ['orders' => $orders, 'menus' => $menus]);
    }


}
