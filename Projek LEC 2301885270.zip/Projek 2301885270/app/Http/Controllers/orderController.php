<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Order;

class orderController extends Controller
{
    public function store(Request $request)
    {
        // $user_id = $request['user_id'];
        $menu_id = $request['menu_id'];
        $quantity = $request->input('quantity');

        $order = new Order();
        // $order->user_id = $user_id;
        $order->menu_id = $menu_id;
        $order->quantity = $quantity;

        $order-> save();
            return redirect('/menu');

  }

}
