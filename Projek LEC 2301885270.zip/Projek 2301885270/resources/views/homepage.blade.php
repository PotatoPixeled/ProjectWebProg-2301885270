@extends('layouts.layout')
@section('content')
<link rel="stylesheet" href="<?php echo asset('css/home.css')?>" type="text/css">

<div class="boxes">
    <div class="box">
        <h1>
            Order Indomie Online
        <h1>

        <div class="choice">
            <button class="button"> <a href="/login">Login</a> </button>
            <button class="button"> <a href="/register"> Register</a> </button>
        </div>
    </div>
</div>




@endsection
