@extends('layouts.layout')
@section('content')
<link rel="stylesheet" href="<?php echo asset('css/login.css')?>" type="text/css">
<div class="cons">
    <div class="box">
        <div class="title">
            <h1>
                Login
            </h1>
        </div>

        <div class="forms">
            <form action="{{ route('customLogin') }}" method="POST">
                @csrf

                <div class="input-field">
                    <h3>Email: </h3> <input type="email">
                    <h3>Password: </h3> <input type="password" pattern="[A-Za-z0-9]{8,}">
                </div>


                <div class="btn-submit">

                    <button type="submit" class="btn-submit">
                        <a href="/menu">Login</a>
                    </button>

                </div>

            </form>
        </div>
    </div>
</div>



@endsection
