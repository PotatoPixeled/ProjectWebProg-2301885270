@extends('layouts.layout')
@section('content')
<link rel="stylesheet" href="<?php echo asset('css/payment.css')?>" type="text/css">
    <div class="box">
        <div class="pay">
            @php
                $total = isset($total) ? $total + ($menu->price * $order->quantity) : 0;
            @endphp

            @foreach ($orders as $order)
                @foreach ($menus as $menu)
                    @if ($order->menu_id == $menu->id)

                        <div class="order">
                            <div class="item">
                                {{$menu->menu_name}} - Rp. {{$menu->price}}
                            </div>
                            <div class="qty">
                                Qty : {{$order->quantity}}
                            </div>
                        </div>


                        @php($total = $total +( $menu->price * $order->quantity))

                    @endif
                @endforeach
            @endforeach

        </div>
        <div class="total">
            Total : Rp. {{ $total }}
        </div>
        <br>
        <a href="/menu"><button>Back</button></a>
    </div>

@endsection
