@extends('layouts.layout')
@section('content')
    <link rel="stylesheet" href="<?php echo asset('css/menu.css')?>" type="text/css">

    <div class="header">
        <div class="top">
           <h1 id="title">Menu Indomie</h1>
        </div>
    </div>

    <div class="content">
        <div class="top">
            <div class="container">
                <div class="menu">
                    <img id="telur" src="{{ URL::to('/assets/telur.jpg') }}">
                    <div class="menu-name">
                        1. Indomie Goreng Telur
                    </div>
                    <div class="menu-price">
                        Rp. 10.000
                    </div>
                </div>
                <div class="menu">
                    <img id="komplit" src="{{ URL::to('/assets/komplit.jpg') }}">
                    <div class="menu-name">
                        2. Indomie Goreng Komplit
                    </div>
                    <div class="menu-price">
                        Rp. 20.000
                    </div>
                </div>
                <div class="menu">
                    <img id="sosis" src="{{ URL::to('/assets/sosis.jpg') }}">
                    <div class="menu-name">
                        3. Indomie Goreng Sosis
                    </div>
                    <div class="menu-price">
                        Rp. 15.000
                    </div>
                </div>
            </div>
        </div>


        <div class="bottom">
            <div class="list">
                <div class="small-title">
                    Cart
                </div>
                @foreach ($orders as $order)
                    @foreach ($menus as $menu)
                        @if ($order->menu_id == $menu->id)

                            <div class="listorder">
                                <div class="item">
                                    {{$menu->menu_name}}
                                </div>
                                <div class="qty">
                                    Qty : {{$order->quantity}}
                                </div>
                                <div class="delete">
                                    <a href= {{"delete/".$order['id']}} ><button id="delete-but"> Delete</button></a>
                                </div>
                            </div>
                        @endif
                    @endforeach
                @endforeach
            </div>

            <div class="order">
                <form action="/order" method="POST">
                    {{ csrf_field() }}
                        <br>Menu   : <input type="number" name="menu_id" id="menu_id">
                        <br>Jumlah : <input type="number" name="quantity" id="quantity">

                        <br><input type="submit" value="Add" style="size: 20px">

                </form>
                <br>
                <a href="/payment"><button>Done</button></a>
            </div>

        </div>

    </div>

@endsection
