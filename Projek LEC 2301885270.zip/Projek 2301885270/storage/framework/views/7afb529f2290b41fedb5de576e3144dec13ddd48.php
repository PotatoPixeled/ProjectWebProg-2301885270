<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/payment.css')?>" type="text/css">
    <div class="box">
        <div class="pay">
            <?php
                $total = isset($total) ? $total + ($menu->price * $order->quantity) : 0;
            ?>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($order->menu_id == $menu->id): ?>

                        <div class="order">
                            <div class="item">
                                <?php echo e($menu->menu_name); ?> - Rp. <?php echo e($menu->price); ?>

                            </div>
                            <div class="qty">
                                Qty : <?php echo e($order->quantity); ?>

                            </div>
                        </div>


                        <?php ($total = $total +( $menu->price * $order->quantity)); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="total">
            Total : Rp. <?php echo e($total); ?>

        </div>
        <br>
        <a href="/menu"><button>Back</button></a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/payment.blade.php ENDPATH**/ ?>