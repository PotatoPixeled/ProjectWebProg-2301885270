<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/image.css')?>" type="text/css">

    <div class="box1">
        <div class="back">
            <button id="back"><a href="/menu">Back to Menu</a></button>
        </div>

        <div class="title-image">
            <h2> Share your Indomie Creation! </h2>
        </div>

    </div>



<div class="container-upload">

    <div class="success">
        <?php if($message = Session::get('success')): ?>

            <div class="alert-success">
                    <strong><?php echo e($message); ?></strong>
            </div>

            <div class="image-uploaded">
                <img src="images/<?php echo e(Session::get('image')); ?>">
            </div>

        <?php endif; ?>
    </div>

    <div class="error">
        <?php if(count($errors) > 0): ?>

            <div class="alert-failed">
                <strong>Oops!</strong> Something wrong with your upload!
            </div>

        <?php endif; ?>
    </div>

        <div class="form-image">
            <form action="<?php echo e(route('image.upload.post')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="buttons">

                    <div class="button-one">
                        <input type="file" name="image" class="form-control">
                    </div>

                    <div class="button-two">
                        <button type="submit" class="button-upload">Upload</button>
                    </div>

                </div>
            </form>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/imageUpload.blade.php ENDPATH**/ ?>