<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/menu.css')?>" type="text/css">

    <div class="header">
        <div class="top">
           <h1 id="title">Menu Indomie</h1>
        </div>
    </div>

    <div class="content">
        <div class="top">
            <div class="container">
                <div class="menu">
                    <img id="telur" src="<?php echo e(URL::to('/assets/telur.jpg')); ?>">
                    <div class="menu-name">
                        1. Indomie Goreng Telur
                    </div>
                    <div class="menu-price">
                        Rp. 10.000
                    </div>
                </div>
                <div class="menu">
                    <img id="komplit" src="<?php echo e(URL::to('/assets/komplit.jpg')); ?>">
                    <div class="menu-name">
                        2. Indomie Goreng Komplit
                    </div>
                    <div class="menu-price">
                        Rp. 20.000
                    </div>
                </div>
                <div class="menu">
                    <img id="sosis" src="<?php echo e(URL::to('/assets/sosis.jpg')); ?>">
                    <div class="menu-name">
                        3. Indomie Goreng Sosis
                    </div>
                    <div class="menu-price">
                        Rp. 15.000
                    </div>
                </div>
            </div>
        </div>


        <div class="bottom">
            <div class="list">
                <div class="small-title">
                    Cart
                </div>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($order->menu_id == $menu->id): ?>

                            <div class="listorder">
                                <div class="item">
                                    <?php echo e($menu->menu_name); ?>

                                </div>
                                <div class="qty">
                                    Qty : <?php echo e($order->quantity); ?>

                                </div>
                                <div class="delete">
                                    <a href= <?php echo e("delete/".$order['id']); ?> ><button id="delete-but"> Delete</button></a>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="order">
                <form action="/order" method="POST">
                    <?php echo e(csrf_field()); ?>

                        <br>Menu   : <input type="number" name="menu_id" id="menu_id">
                        <br>Jumlah : <input type="number" name="quantity" id="quantity">

                        <br><input type="submit" value="Add" style="size: 20px">

                </form>
                <br>
                <a href="/payment"><button>Done</button></a>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/menupage.blade.php ENDPATH**/ ?>