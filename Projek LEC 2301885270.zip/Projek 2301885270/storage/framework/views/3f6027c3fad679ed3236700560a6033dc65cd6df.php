<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/home.css')?>" type="text/css">

<div class="boxes">
    <div class="box">
        <h1>
            Order Indomie Online
        <h1>

        <div class="choice">
            <button class="button"> <a href="/login">Login</a> </button>
            <button class="button"> <a href="/register"> Register</a> </button>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/homepage.blade.php ENDPATH**/ ?>