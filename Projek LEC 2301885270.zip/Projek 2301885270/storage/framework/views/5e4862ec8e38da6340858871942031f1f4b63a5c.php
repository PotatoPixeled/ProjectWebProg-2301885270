<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/login.css')?>" type="text/css">
<div class="cons">
    <div class="box">
        <div class="title">
            <h1>
                Login
            </h1>
        </div>

        <div class="forms">
            <form action="<?php echo e(route('customLogin')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="input-field">
                    <h3>Email: </h3> <input type="email">
                    <h3>Password: </h3> <input type="password" pattern="[A-Za-z0-9]{8,}">
                </div>


                <div class="btn-submit">

                    <button type="submit" class="btn-submit">
                        <a href="/menu">Login</a>
                    </button>

                </div>

            </form>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/loginpage.blade.php ENDPATH**/ ?>