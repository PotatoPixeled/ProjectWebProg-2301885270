<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>homepage</title>
</head>
<body>
    
    <h1>
        Selamat Datang di Perpustakaan Online    
    <h1>

    <button> <a href="/login">Login</a> </button>
    <button> <a href="/register"> Register</a> </button>

   
    

</body>
</html><?php /**PATH C:\Users\Jonathan\example-app\resources\views/homepage.blade.php ENDPATH**/ ?>