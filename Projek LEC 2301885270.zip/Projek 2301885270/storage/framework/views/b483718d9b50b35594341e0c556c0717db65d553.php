<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo asset('css/register.css')?>" type="text/css">


    <div class="cons">
        <div class="box">
            <div class="title">
                <h1>
                    Register
                </h1>
            </div>

            <div class="forms">
                <form action="/store" method="POST">
                    <?php echo e(csrf_field()); ?>

                        <div class="inputs">
                            Nama: <input type="text" name="name" id='name' minlength="3" maxlength="22">
                        </div>

                        <div class="inputs">
                            Umur: <input type="number" name="age" id='age' min="18" max="99">
                        </div>
                        <div class="inputs">
                            Email: <input type="email" name='email' id='email'>
                        </div>
                        <div class="inputs">
                            Password: <input type="password" name='password' id='password'>
                        </div>



                        <input type="submit" value="submit">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/registerpage.blade.php ENDPATH**/ ?>