<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RegisterPage</title>
</head>
<body>
    <h1>
        Register
    </h1>
    <form action="">

    <h3>Nama: </h3> <input type="text">
    <h3>Email: </h3> <input type="text">
    <h3>Password: </h3> <input type="text">
    <h3>usia: </h3> <input type="text">

    <button> <a href="/home"> Register</a> </button>

    </form>
</body>
</html><?php /**PATH C:\Users\Jonathan\example-app\resources\views/registerpage.blade.php ENDPATH**/ ?>