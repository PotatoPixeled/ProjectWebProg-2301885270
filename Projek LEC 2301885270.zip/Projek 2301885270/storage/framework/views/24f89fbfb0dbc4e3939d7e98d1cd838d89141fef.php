<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo asset('css/layout.css')?>" type="text/css">
    <title>Loginpage</title>
</head>
<body>
    <div class="headers">
        <div class="logo">
            Warm-indo
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <div class="footers">

        Submit your Indomie Creation<a href="/image-upload" id="here"> HERE!</a>

        <p>Marcellino Adryan Halim - 2301885270</p>
    </div>
</body>
</html>
<?php /**PATH F:\SUNIB\Semester 5\Web Programming\Projek 2301885270\resources\views/layouts/layout.blade.php ENDPATH**/ ?>