
<form method="post" action="submitmyform">

	<p>
		<label>Name</label>
		<input type="text" name="name" value="<?php echo e(old("name")); ?>"/>
	</p>
     <p>
     <label>Email</label>
		<input type="text" name="email" value="<?php echo e(old("email")); ?>"/>
     </p>
	<p>
     <label>Age</label>
		<input type="text" name="age" value="<?php echo e(old("age")); ?>"/>
     </p>
      <p>
      	<input type="submit" name="Submit">
      </p>
</form>
<?php /**PATH F:\SUNIB\Semester 5\Web Programming\example-app\resources\views/form/form.blade.php ENDPATH**/ ?>