<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('menu')->insert([
            [
                'id' => 1,
                'menu_name' => 'Indomie Goreng Telur',
                'price' => 10000
            ],
            [
                'id' => 2,
                'menu_name' => 'Indomie Goreng Komplit',
                'price' => 20000
            ],
            [
                'id' => 3,
                'menu_name' => 'Indomie Goreng Sosis',
                'price' => 15000
            ],


        ]);
    }
}
