<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller1;
use App\Http\Controllers\loginController;
use App\Http\Controllers\menuController;
use App\Http\Controllers\orderController;
use App\Http\Controllers\paymentController;
use App\Http\Controllers\ImageUploadController;

Route::get('/', function () {return view('homepage');});

Route::get('login', [loginController::class, 'index'])->name('login');
Route::post('custom-login', [loginController::class, 'customLogin'])->name('customLogin');

Route::get('/register', function () {return view('registerpage');});

Route::post('/store',[Controller1::class, 'store']);

Route::get('/menu', [menuController::class, 'list']);
Route::get('/delete/{id}', [menuController::class, 'delete']);

Route::post('/order',[orderController::class, 'store']);

Route::get('/payment', [paymentController::class,'show']);

Route::get('image-upload', [ ImageUploadController::class, 'imageUpload' ])->name('image.upload');
Route::post('image-upload', [ ImageUploadController::class, 'imageUploadPost' ])->name('image.upload.post');
